/* 包含的头文件 --------------------------------------------------------------*/
#include "bsp.h"

/************************************************
函数名称 ： CLK_Configuration
功    能 ： 时钟配置
参    数 ： 无
返 回 值 ： 无
*************************************************/
void CLK_Configuration(void)
{
  CLK_HSICmd(ENABLE);                            //启用内部高速时钟
  CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1); //配置HSI时钟分频系数为1，16MHZ供给CPU
}

/************************************************
函数名称 ： GPIO_Configuration
功    能 ： 基本IO引脚配置
参    数 ： 无
返 回 值 ： 无
*************************************************/
void GPIO_Configuration(void)
{
  GPIO_Init(GPIOC, GPIO_PIN_4, GPIO_MODE_IN_PU_NO_IT);
  
  GPIO_Init(KEY_GPIO_PORT, (GPIO_Pin_TypeDef)KEY_GPIO_PIN, GPIO_MODE_IN_PU_NO_IT );  //上拉输入
  
  GPIO_Init(LED1_GPIO_PORT, (GPIO_Pin_TypeDef)LED1_GPIO_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
  GPIO_Init(TCSLED_GPIO_PORT, (GPIO_Pin_TypeDef)TCSLED_GPIO_PIN, GPIO_MODE_OUT_PP_LOW_FAST);

}

#define CCR1_Val ((uint16_t)0)
#define CCR2_Val ((uint16_t)0)
#define CCR3_Val ((uint16_t)0)
#define CCR4_Val ((uint16_t)0)

void TIM1_Configuration(void)
{
  TIM1_DeInit();
  /*
    TIM1_Prescaler：预分频值-1
    TIM1_CounterMode： 计数方式
    TIM1_Period：计数值的最大值
    TIM1_RepetitionCounter：指定重复计数器的值
    频率 f = 16000000/(TIM1_Prescaler + 1)/TIM1_Period
    周期 T = 1/f
    */
  // 用于控制电机，不分频，20kHz频率
  TIM1_TimeBaseInit(0, TIM1_COUNTERMODE_UP, PWM_LIMIT_VALUE-1, 0);

  TIM1_OC1Init(TIM1_OCMODE_PWM2, TIM1_OUTPUTSTATE_ENABLE, TIM1_OUTPUTNSTATE_ENABLE,
               CCR1_Val, TIM1_OCPOLARITY_LOW, TIM1_OCNPOLARITY_HIGH, TIM1_OCIDLESTATE_SET,
               TIM1_OCNIDLESTATE_RESET);

  /*TIM1_Pulse = CCR2_Val*/
  TIM1_OC2Init(TIM1_OCMODE_PWM2, TIM1_OUTPUTSTATE_ENABLE, TIM1_OUTPUTNSTATE_ENABLE, CCR2_Val,
               TIM1_OCPOLARITY_LOW, TIM1_OCNPOLARITY_HIGH, TIM1_OCIDLESTATE_SET,
               TIM1_OCNIDLESTATE_RESET);

  /*TIM1_Pulse = CCR3_Val*/
  TIM1_OC3Init(TIM1_OCMODE_PWM2, TIM1_OUTPUTSTATE_ENABLE, TIM1_OUTPUTNSTATE_ENABLE,
               CCR3_Val, TIM1_OCPOLARITY_LOW, TIM1_OCNPOLARITY_HIGH, TIM1_OCIDLESTATE_SET,
               TIM1_OCNIDLESTATE_RESET);

  /*TIM1_Pulse = CCR4_Val
  TIM1_OC4Init(TIM1_OCMODE_PWM2, TIM1_OUTPUTSTATE_ENABLE, CCR4_Val, TIM1_OCPOLARITY_LOW,
               TIM1_OCIDLESTATE_SET);*/

  /* TIM1 counter enable */
  TIM1_Cmd(ENABLE);

  /* TIM1 Main Output Enable */
  TIM1_CtrlPWMOutputs(ENABLE);
}

void TIM2_Configuration(void)
{
  // 用于控制舵机，16分频，频率为50hz
  TIM2_DeInit();
  TIM2_TimeBaseInit(TIM2_PRESCALER_1, PWM_LIMIT_VALUE - 1);

  TIM2_OC1Init(TIM2_OCMODE_PWM2, TIM2_OUTPUTSTATE_ENABLE, 0, TIM2_OCPOLARITY_LOW);
  TIM2_OC1PreloadConfig(ENABLE);
  TIM2_CCxCmd(TIM2_CHANNEL_1, ENABLE);
/*
  TIM2_OC2Init(TIM2_OCMODE_PWM2, TIM2_OUTPUTSTATE_ENABLE, 0, TIM2_OCPOLARITY_LOW);
  TIM2_OC2PreloadConfig(ENABLE);
  TIM2_CCxCmd(TIM2_CHANNEL_2, ENABLE);*/

  // 启动定时器2
  TIM2_Cmd(ENABLE);
}

void I2C_Configuration()
{
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_I2C, ENABLE);
  I2C_DeInit();
  I2C_Init(100000, SLAVE_ADDRESS, I2C_DUTYCYCLE_2, I2C_ACK_CURR, I2C_ADDMODE_7BIT, 1);
  //I2C_Init(400000, SLAVE_ADDRESS, I2C_DUTYCYCLE_2, I2C_ACK_CURR, I2C_ADDMODE_7BIT, 100);
  I2C_ITConfig((I2C_IT_TypeDef)(I2C_IT_ERR | I2C_IT_EVT | I2C_IT_BUF), ENABLE);
}

/************************************************
函数名称 ： BSP_Initializes
功    能 ： 板级支持包初始化
参    数 ： 无
返 回 值 ： 无
*************************************************/
void BSP_Initializes(void)
{
  CLK_Configuration();
  GPIO_Configuration();
  TIM1_Configuration();
  TIM2_Configuration();
  //I2C_Configuration();
  //Time4_Configuration();
  ADC_Configuration();
}

void BSP_LED_Flash_State(u8 led_flash)
{
  if (led_flash >= 1 && led_flash < 4)
  {
    LED_ON();
  }
  else if (led_flash >= 4 && led_flash < 7)
  {
    LED_OFF();
  }
  else if (led_flash >= 7 && led_flash < 10)
  {
    LED_ON();
  }
  else if (led_flash >= 10 && led_flash < 13)
  {
    LED_OFF();
  }
}

/**
 * @Brief: Delayus
 * @Note: 微秒延迟函数
 * @Parm: 无
 * @Retval: 无
 */
void Delayus(u32 us)
{
  u32 i;
  for (i = us; i > 0; i--)
  {
    asm("nop"); //1/16M = 0.0625us,一个机器周期
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
    asm("nop");
  }
}

/**
 * @Brief: Delayms
 * @Note: 毫秒延迟函数
 * @Parm: 无
 * @Retval: 无
 */
void Delayms(u32 ms)
{
  u32 i;
  for (i = ms; i > 0; i--)
    Delayus(1000);
}

/******** END OF FILE ****/
