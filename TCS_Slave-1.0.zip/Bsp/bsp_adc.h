/*
 * @Author: Malloy.Yuan
 * @Wechat: ymlin96546
 * @Date: 2019-06-26 11:19:23
 * @LastEditors: Malloy.Yuan
 * @LastEditTime: 2019-08-13 10:33:55
 */
/* 定义防止递归包含 ----------------------------------------------------------*/
#ifndef _BSP_ADC_H
#define _BSP_ADC_H

/* 包含的头文件 --------------------------------------------------------------*/
#include "bsp.h"

/* 宏定义 --------------------------------------------------------------------*/
#define	ADSAMPLEMAX		8	//采样的有效次数	
#define	ADSHIFT				3	//位移位个数

/* 变量引用接口声明 --------------------------------------------------------------------*/
extern u16 Battery_Vol_AD;

/* 函数申明 ------------------------------------------------------------------*/
void ADC_Configuration(void);
uint16_t OneChannelGetADValue(void);

#endif /* _BSP_ADC_H */

/**** Copyright (C)2017 strongerHuang. All Rights Reserved **** END OF FILE ****/
