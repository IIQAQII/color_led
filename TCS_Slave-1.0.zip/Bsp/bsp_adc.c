/*
 * @Author: Malloy.Yuan
 * @Wechat: ymlin96546
 * @Date: 2019-08-10 11:35:05
 * @LastEditors: Malloy.Yuan
 * @LastEditTime: 2019-08-13 11:35:35
 */
/* 包含的头文件 --------------------------------------------------------------*/
#include "bsp_adc.h"


u16 Battery_Vol_AD;
/**
 * @Brief: ADC_Init
 * @Note: adc1初始化操作,ADC1_Init函数的形参不能使用或运算初始化多通道ADC
 * @Parm: 无
 * @Retval: 无
 */
void ADC_Configuration(void)
{
  /* De-Init ADC peripheral*/
  ADC1_DeInit();
  /**< 连续转换模式 */
  /**< 使能通道 */
  /**< ADC时钟：fADC1 = fcpu/18 */
  /**< 这里设置了从TIM TRGO 启动转换，但实际是没有用到的*/
  /**  不使能 ADC1_ExtTriggerState**/
  /**< 转换数据右对齐 */
  /**< 不使能通道10的斯密特触发器 */
  /**  不使能通道10的斯密特触发器状态 */
  ADC1_Init(ADC1_CONVERSIONMODE_CONTINUOUS , ADC1_CHANNEL_2, ADC1_PRESSEL_FCPU_D8,ADC1_EXTTRIG_TIM, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL2,DISABLE);
  ADC1_Cmd(ENABLE);
  /*Start Conversion */
  ADC1_StartConversion();
}

/**
 * @Brief: OneChannelGetADValue
 * @Note: ADC1单通道AD值读取采调用该函数，只需初始化ADC_Init一次后连续使用该函数读值即可 
 * @Parm: 无
 * @Retval: AD_Result 多选读取通道的AD值
 */
u16 OneChannelGetADValue(void)
{
  u8 i;
  u16 AD_Max = 0;
  u16 AD_Min = 0xFFFF;
  u16 AD_Buffer = 0;
  u16 AD_Result = 0;

  for(i=0; i<ADSAMPLEMAX+2; i++)//采用平滑滤波,采样十次,去除最大值,最小值得出8次有效值
  {
    ADC1->CSR &= ~ADC1_CSR_EOC; //清除AD转换标志
    while(ADC1->CSR & ADC1_CSR_EOC == ADC1_CSR_EOC);				//ADC转换完成标志
    //ADC转换结果(12bit):ADCRH (高8位) 及ADCRL (低4位)
    AD_Buffer = ADC1_GetConversionValue();

    AD_Result += AD_Buffer;
    
    if(AD_Buffer < AD_Min)
    {
      AD_Min = AD_Buffer;
    }
    if(AD_Buffer > AD_Max)
    {
      AD_Max = AD_Buffer;
    }		
  }

  AD_Result = (AD_Result - AD_Min - AD_Max) >> ADSHIFT;//左移或右移N位等于扩大或缩小2的N次方倍,等价于AD_Result/8		
	
  return AD_Result;

}


/**** Copyright (C)2017 yahboom. All Rights Reserved **** END OF FILE ****/