/* 定义防止递归包含 ----------------------------------------------------------*/
#ifndef _BSP_H_
#define _BSP_H_

/* 包含的头文件 --------------------------------------------------------------*/
#include <stdio.h>

#include "stm8s.h"
#include "bsp_timer.h"
#include "bsp_pwm.h"
#include "bsp_adc.h"


#define MCU_VERSION                6


/* Define Slave Address  ---------------------------------------------------*/
#define SLAVE_ADDRESS              0x36


/* 宏定义 --------------------------------------------------------------------*/
#define LED1_GPIO_PORT            GPIOA
#define LED1_GPIO_PIN             GPIO_PIN_3

#define LED_ON()                  GPIO_WriteHigh(LED1_GPIO_PORT, LED1_GPIO_PIN)
#define LED_OFF()                 GPIO_WriteLow(LED1_GPIO_PORT, LED1_GPIO_PIN)

#define TCSLED_GPIO_PORT          GPIOD
#define TCSLED_GPIO_PIN           GPIO_PIN_4

#define TCSLED_ON()               GPIO_WriteHigh(TCSLED_GPIO_PORT, TCSLED_GPIO_PIN)
#define TCSLED_OFF()              GPIO_WriteLow(TCSLED_GPIO_PORT, TCSLED_GPIO_PIN)

#define LED_REVERSE()             GPIO_WriteReverse(LED1_GPIO_PORT, LED1_GPIO_PIN)

#define KEY_GPIO_PORT             GPIOD
#define KEY_GPIO_PIN              GPIO_PIN_2

#define KEY_READ              GPIO_ReadInputPin(KEY_GPIO_PORT, KEY_GPIO_PIN)


/* 函数申明 ------------------------------------------------------------------*/

void BSP_Initializes(void);
void Delayus(u32 us);
void Delayms(u32 ms);
void BSP_LED_Flash_State(u8 led_flash);

#endif /* _BSP_H_ */
