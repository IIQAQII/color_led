#include "bsp_pwm.h"

/*
 * PWM�����Ӧ��ϵ��
 * PWM1-PC5-TIM2_CH1
 * PWM2-PD3-TIM2_CH2
*/

int pwmstopz = 0;

u16 Pwm_Convert_rgb(u16 speed)
{
  /* (x-in_min)*(out_max-out_min)/(in_max-in_min)+out_min */
  u16 value = speed;
  if (value > RGB_MAX) value = RGB_MAX;

  // value = value * 20000 / 255;
  value = value * PWM_LIMIT_VALUE/ RGB_MAX;

  return (u16)value;
}

void Pwm_T1C1_R(u16 duty)
{
  TIM1_SetCompare1(Pwm_Convert_rgb(duty));
}

void Pwm_T1C2_G(u16 duty)
{
  TIM1_SetCompare2(Pwm_Convert_rgb(duty));
}

void Pwm_T1C3_B(u16 duty)
{
  TIM1_SetCompare3(Pwm_Convert_rgb(duty));
}

void Pwm_T2C1_W(u16 duty)
{
  TIM2_SetCompare1(Pwm_Convert_rgb(duty));
}
