/**
  **********************************  STM8S  ***********************************
  * @文件名     ： main.c
  * @作者       ： chengengyue
  * @库版本     ： V2.2.0
  * @文件版本   ： V1.0.0
  * @日期       ： 2020年9月15日
  * @摘要       ： 单片机主函数
  *****************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "bsp.h"
#include "tcs34725.h"

#define FLASH_TIME   300
#define HEART_BEAT   1

//extern __IO uint8_t Slave_Buffer_Rx[255];
//extern __IO uint8_t Rx_Idx;
//extern __IO uint8_t g_Update;
//uint16_t regval = 0;
//uint8_t Slave_Buffer[255];
uint16_t vibration_ad_time = 1;
uint16_t Vibration_Vol_AD = 1;
uint8_t Vibration_temp = 0;
uint8_t key = 0;
u16 red = 0;
u16 green = 0;
u16 blue = 0;
u16 bili = 0;

void System_Initializes(void)
{
  BSP_Initializes();
  //Flash_Option_AFR_Config();
}

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void main(void)
{
  //u8 led_flash = 0;
  //u8 i = 0;

  System_Initializes();
  enableInterrupts();

  /* 启动看门狗 内存不足，不要看门狗了
  Test_IWDGReset();
  IWDG_Conf();*/

  LED_OFF();
  TCSLED_OFF();
  Pwm_T1C1_R(0);
  Pwm_T1C2_G(0);
  Pwm_T1C3_B(0);
  Pwm_T2C1_W(0);
  
  Delayms(2000);
  TCS34725_Init();
  Delayms(200);
  //TCSLED_ON();
  //Delayms(2);
  //TCS34725_GetRawData(&rgb);
  //Delayms(2);
  //TCS34725_GetRawData(&rgb);
/*
          Vibration_temp = 1;
          Pwm_T2C1_W(0);
          TCSLED_ON();
          Delayms(500);
          TCS34725_GetRawData(&rgb);
          Delayms(2);
          TCS34725_GetRawData(&rgb);
          Delayms(2);
          bili = rgb.c/10;
          red = (u16)(rgb.r*35/bili);//1.5/2.3  350
          green = (u16)(rgb.g*54/bili);//608.72
          blue = (u16)(rgb.b*30/bili);
          if(red>=80 && green<=210 && blue<110)
          {
            Pwm_T1C1_R(255);
            Pwm_T1C2_G(0);
            Pwm_T1C3_B(0);
          }
          else if(red<80 && green>210 && blue<=110)
          {
              Pwm_T1C1_R(0);
              Pwm_T1C2_G(255);
              Pwm_T1C3_B(0);
          }
          else if(red<80 && green>210 && blue>110)
          {
            Pwm_T1C1_R(0);
            Pwm_T1C2_G(0);
            Pwm_T1C3_B(255);
          }
          else
          {
            red = (u16)(red*2.6);//1.5/2.3
            green = (u16)(green*1.1);
            blue = blue/40;
            Pwm_T1C1_R(red);
            Pwm_T1C2_G(green);
            Pwm_T1C3_B(blue);
          }
          Vibration_Vol_AD = 0;
          TCSLED_OFF();
          Delayms(1000);*/
  /*Main Loop  */
  while (1)
  {
    Vibration_Vol_AD = OneChannelGetADValue();
    //Slave_Buffer[i] = Vibration_Vol_AD;i++;
    if (!KEY_READ)//按下低电平
    {
      while (!KEY_READ);
      if (key == 0)  key = 1;
      else if (key == 1)  key = 0;
    }
    if (key == 0)
    {
      Pwm_T1C1_R(0);
      Pwm_T1C2_G(0);
      Pwm_T1C3_B(0);
      Pwm_T2C1_W(0);
      Vibration_temp = 0;
    }
    else if (key == 1)
    {
      if (Vibration_Vol_AD == 0)
      {
        Delayms(5);
        if (Vibration_Vol_AD == 0)
        {
          Vibration_temp = 1;
          Pwm_T2C1_W(0);
          TCSLED_ON();
          Delayms(500);
          TCS34725_GetRawData(&rgb);
          Delayms(2);
          TCS34725_GetRawData(&rgb);
          Delayms(2);
          bili = rgb.c/10;
          red = (u16)(rgb.r*35/bili);//1.5/2.3  350
          green = (u16)(rgb.g*54/bili);//*608.72
          blue = (u16)(rgb.b*30/bili);
          if(red>=80 && green<=210 && blue<110)
          {
            Pwm_T1C1_R(255);
            Pwm_T1C2_G(0);
            Pwm_T1C3_B(0);
          }
          else if(red<80 && green>210 && blue<=110)
          {
              Pwm_T1C1_R(0);
              Pwm_T1C2_G(255);
              Pwm_T1C3_B(0);
          }
          else if(red<80 && green>210 && blue>110)
          {
            Pwm_T1C1_R(0);
            Pwm_T1C2_G(0);
            Pwm_T1C3_B(255);
          }
          else
          {
            red = (u16)(red*2.6);//1.5/2.3
            green = (u16)(green*1.1);
            blue = blue/40;
            Pwm_T1C1_R(red);
            Pwm_T1C2_G(green);
            Pwm_T1C3_B(blue);
          }
          Vibration_Vol_AD = 0;
          TCSLED_OFF();
          Delayms(1000);
        }
      }
      if (Vibration_temp == 0)
      {
        Pwm_T2C1_W(255);
      }
    }
    
    /*
    if (Timer_Count <= 1)
    {
      Timer_Count = 100;
      // LED_REVERSE();
      led_flash++;
      if (led_flash%3 == 0)
      {
        // 单片机底层状态指示灯，单片机正常运行时每三秒闪2次
        BSP_LED_Flash_State(led_flash);
        if (led_flash >= 30) {led_flash = 0;}
      }
    }*/
    /* 独立看门狗 重新计数 
    IWDG_ReloadCounter();*/
  }
}


#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
